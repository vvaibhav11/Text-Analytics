# -*- coding: utf-8 -*-
"""
Created on Tue Feb 22 15:46:52 2022

@author: vvaib
"""

# Setup
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
import joblib
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import confusion_matrix
from sklearn.naive_bayes import GaussianNB
import nltk
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
from wordcloud import WordCloud
import itertools
nltk.download('stopwords')
from collections import Counter
import re

# Loading dataset
df = pd.read_csv("Train_rev1.csv")
df = df.sample(n = 2500)
#df = df.head(2500)
df.describe()
df.head()

# Listing percentile of normalized salary and flagging with percentile equal to higher than 75
df['percentile'] = df.SalaryNormalized.rank(pct = True)*100
df['salary_cat'] = np.where(pd.DataFrame(df['percentile'] >= 75),1,0)

df['salary_cat'].nunique()

# Defining independent and dependent variables
x = df['FullDescription']
y = df['salary_cat']

#Intial cleaning/ pre-processing
def preprocess(data):
    # Remove irrelevant columns
    data = data.drop(['Id', 'Title', 'LocationRaw', 'LocationNormalized', 'ContractType', 'ContractTime', 'Company', 
                      'Category','SalaryRaw','SalaryNormalized','SourceName','percentile'], axis=1)
    
    # Convert text to lowercase
    data['FullDescription'] = data['FullDescription'].str.strip().str.lower()
    return data

df = preprocess(df)

# Split into training and testing data
x = df['FullDescription']
y = df['salary_cat']
x, x_test, y, y_test = train_test_split(x,y, stratify=y, test_size=0.20, random_state=42)

# Vectorize text reviews to numbers
vec = CountVectorizer(stop_words='english')
x = vec.fit_transform(x).toarray()
x_test = vec.transform(x_test).toarray()

###############################################################################
################ Model building using Multinomial Naive Bayes #################
model = MultinomialNB()
model.fit(x, y)
y_pred = model.predict(x_test)

# Accuracy of the model
model.score(x_test, y_test)

# Confusion matrix
print("Confusion Matrix (0 is the minority label: Above):\n")
mat = confusion_matrix(y_test, y_pred)
sns.heatmap(mat, annot=True, fmt='g')
plt.xlabel('true label')
plt.ylabel('predicted label');
plt.show()

###############################################################################
################# Model building using Gaussian Naive Bayes ###################
model2 = GaussianNB()
model2.fit(x, y)
y_pred = model2.predict(x_test)

# Accuracy of the model
model.score(x_test, y_test)

# Confusion matrix
print("Confusion Matrix (0 is the minority label: Above):\n")
mat = confusion_matrix(y_test, y_pred)
sns.heatmap(mat, annot=True, fmt='g')
plt.xlabel('true label')
plt.ylabel('predicted label');
plt.show()

###############################################################################
########################## Removing Stop words #################
df['no_stopword']= df["FullDescription"].str.lower().tolist()
stop_words = stopwords.words('english')

def remove_stop_words(corpus):
    removed_stop_words = []
    for review in corpus:
        removed_stop_words.append(
            ' '.join([word for word in review.split() 
                      if word not in stop_words and word.isalpha()])
        )
    return removed_stop_words

df['no_stopword'] = remove_stop_words(df['FullDescription'])

##################### Frequency of words (high/low) salary #######################
# High Salary
f1 = pd.DataFrame(df[(df['salary_cat'] == 1)])
f1["no_stopword"] = f1['no_stopword'].str.lower().str.replace('[^\w\s]','')
 
high_sal = f1.no_stopword.str.split(expand=True).stack().value_counts().reset_index()
high_sal.columns = ['word', 'frequency']
high_sal2 = high_sal.head(10)

# Word cloud
data = high_sal.set_index('word').to_dict()['frequency']
wc = WordCloud(width=800, height=400, max_words=200).generate_from_frequencies(data)
plt.figure(figsize=(10, 10))
plt.imshow(wc, interpolation='bilinear')
plt.axis('off')
plt.show()

# Low Salary
f2 = pd.DataFrame(df[(df['salary_cat'] == 0)])
f2["no_stopword"] = f2['no_stopword'].str.lower().str.replace('[^\w\s]','')
 
low_sal = f2.no_stopword.str.split(expand=True).stack().value_counts().reset_index()
low_sal.columns = ['word', 'frequency']
low_sal2 = low_sal.head(10)

# Word cloud
data = low_sal.set_index('word').to_dict()['frequency']
wc = WordCloud(width=800, height=400, max_words=200).generate_from_frequencies(data)
plt.figure(figsize=(10, 10))
plt.imshow(wc, interpolation='bilinear')
plt.axis('off')
plt.show()

#######################################################################################
##################################### Problem 2 #######################################
# Text descriptions can be cleaned to increase the accuracy using below techniques
# Removing stop words
# Lemmatization
# Tokenization
# Removing unwarranted tags
# Further tf-idf vectorizer can be used on cleaned description to check for accuracy

df['no_stopword']= df["FullDescription"].str.lower().tolist()
stop_words = stopwords.words('english')

def remove_stop_words(corpus):
    removed_stop_words = []
    for review in corpus:
        removed_stop_words.append(
            ' '.join([word for word in review.split() 
                      if word not in stop_words and word.isalpha()])
        )
    return removed_stop_words

df['no_stopword'] = remove_stop_words(df['FullDescription'])

################################# Limmization ##########################################

def get_lemmatized_text(corpus):
    
    from nltk.stem import WordNetLemmatizer
    lemmatizer = WordNetLemmatizer()
    return [' '.join([lemmatizer.lemmatize(word) for word in review.split()]) for review in corpus]

df['limmizated'] = get_lemmatized_text(df['no_stopword'])

#################### Tokenize lemmatized comments #####################################

def apwords(words):
    tokenize = []
    words = nltk.pos_tag(word_tokenize(words))
    for w in words:
        tokenize.append(w)
    return tokenize

addwords = lambda x: apwords(x)
df['tokensize'] = df['limmizated'].apply(addwords)

#################### removing unwarrented tags ########################################

token = df['tokensize'].tolist()

final_tags = [ [] for i in range(len(df)) ]

tags = ['FW','JJ','JJR','JJS','MD','NN','NNS','NNP','NNPS','RB','RBR','RBS',
        'SYM','VB','VBD','VBG','VBN']

for i in range(len(token)):
    #print(i)
    for j in range(len(token[i])):
        #print(j)
        for k in tags:
            if k == token[i][j][1]:
                final_tags[i].append(token[i][j][0])
                continue

df['filtered_tags'] = final_tags
df['cleaned_desc'] = df.filtered_tags.apply(' '.join)

########################################################################################
'''Model building on cleaned description using count vectorizer and using Multinomial and Gaussian Naive Bayes 
   Analysis: count vectorizer gave good result on cleaned data when compared with uncleaned count vectorizer and
   cleaned data with tf-idf vectorizer'''

# Split into training and testing data
x = df['cleaned_desc']
y = df['salary_cat']
x, x_test, y, y_test = train_test_split(x,y, stratify=y, test_size=0.20, random_state=42)

# Vectorize text reviews to numbers
vec = CountVectorizer(stop_words='english')
x = vec.fit_transform(x).toarray()
x_test = vec.transform(x_test).toarray()

###############################################################################
################ Model building using Multinomial Naive Bayes #################
model = MultinomialNB()
model.fit(x, y)
y_pred = model.predict(x_test)

# Accuracy of the model
model.score(x_test, y_test)

# Confusion matrix
print("Confusion Matrix (0 is the minority label: Above):\n")
mat = confusion_matrix(y_test, y_pred)
sns.heatmap(mat, annot=True, fmt='g')
plt.xlabel('true label')
plt.ylabel('predicted label');
plt.show()

###############################################################################
################# Model building using Gaussian Naive Bayes ###################
model2 = GaussianNB()
model2.fit(x, y)
y_pred = model2.predict(x_test)

# Accuracy of the model
model.score(x_test, y_test)

# Confusion matrix
print("Confusion Matrix (0 is the minority label: Above):\n")
mat = confusion_matrix(y_test, y_pred)
sns.heatmap(mat, annot=True, fmt='g')
plt.xlabel('true label')
plt.ylabel('predicted label');
plt.show()

########################################################################################
'''Model building on cleaned description using tf-idf vectorizer and using Multinomial and Gaussian Naive Bayes 
Analysis: tf-idf vectorizer gave similar result compared with uncleaned and cleaned data with count vectorizer'''

# Split into training and testing data
x = df['cleaned_desc']
y = df['salary_cat']
x, x_test, y, y_test = train_test_split(x,y, stratify=y, test_size=0.20, random_state=42)

# Vectorize text reviews to numbers
vec = TfidfVectorizer(stop_words= 'english')
x = vec.fit_transform(x).toarray()
x_test = vec.transform(x_test).toarray()

###############################################################################
################ Model building using Multinomial Naive Bayes #################
model = MultinomialNB()
model.fit(x, y)
y_pred = model.predict(x_test)

# Accuracy of the model
model.score(x_test, y_test)

# Confusion matrix
print("Confusion Matrix (0 is the minority label: Above):\n")
mat = confusion_matrix(y_test, y_pred)
sns.heatmap(mat, annot=True, fmt='g')
plt.xlabel('true label')
plt.ylabel('predicted label');
plt.show()

###############################################################################
################# Model building using Gaussian Naive Bayes ###################
model2 = GaussianNB()
model2.fit(x, y)
y_pred = model2.predict(x_test)

# Accuracy of the model
model.score(x_test, y_test)

# Confusion matrix
print("Confusion Matrix (0 is the minority label: Above):\n")
mat = confusion_matrix(y_test, y_pred)
sns.heatmap(mat, annot=True, fmt='g')
plt.xlabel('true label')
plt.ylabel('predicted label');
plt.show()
