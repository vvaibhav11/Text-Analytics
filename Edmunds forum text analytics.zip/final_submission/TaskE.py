import pandas as pd
from textblob import TextBlob
import nltk
from nltk.tokenize import word_tokenize
from nltk import pos_tag
from nltk.corpus import stopwords
from nltk.corpus import wordnet
import collections
from nltk.stem import WordNetLemmatizer
import itertools
from collections import Counter

# Loading comments and model-brands data
data = pd.read_csv('comments_raw.csv')[:5000]
data.head()
model = pd.read_csv('models.csv')
model.head()

model_dict = dict(zip(model.integra, model.acura))
model_dict['integra']='acura'

# Removing non-brand keys from the model-brand dictionary¶
del model_dict["cars"]
del model_dict["seats"]
del model_dict["problems"]
del model_dict["sedans"]

# Replacing models with brands
def replace_all(text):
    for i, j in model_dict.items():
        text = text.replace(j.lower(), i.lower())
    return text

data['com_replaced'] = data['comment'].apply(replace_all)
models_input = list(set(list(model_dict.values())))

brand_list = models_input

# Data cleaning and pre-processing
wl = WordNetLemmatizer()

# Getting part-of-speech tags for comments
pos_dict = {'J':wordnet.ADJ, 'V':wordnet.VERB, 'N':wordnet.NOUN, 'R':wordnet.ADV}
def token_stop_pos(text):
    tags = pos_tag(word_tokenize(text))
    newlist = []
    for word, tag in tags:
        if word.lower() not in set(stopwords.words('english')):
            newlist.append(tuple([word.lower(), pos_dict.get(tag[0])]))
    return newlist

data['pos'] = data['comment'].apply(token_stop_pos)

# lemmatizing comments
def lemmatize(pos_data):
    lemma_rew = " "
    for word, pos in pos_data:
        if not pos:
            lemma = word
            lemma_rew = lemma_rew + " " + lemma
        else:
            lemma = wl.lemmatize(word, pos=pos)
            lemma_rew = lemma_rew + " " + lemma
    return lemma_rew

data['Lemma'] = data['pos'].apply(lemmatize)
data.head()

# performing sentiment analysis on comments
# This is to understand the context of the aspirational words used with reference to brands. TextBlob functions gives output in the form a tuple with two values:
# Positivity (range: -1 to 1): Here, 1 and -1 represent extreme positive and negative ends respectively.
# Subjectivity (range: 0 to 1): Here, 0 represents the statement in general context and one represents the statement in subjective context.
def datablob(lemma):
    return TextBlob(lemma).sentiment

data['Blob'] = data['Lemma'].apply(datablob)

# Defining a set of aspirational words to look out for in comments
aspiration = ['premium', 'luxury', 'lux', 'grace', 'style', 'buy', 'wishlist', 'wish', 'own', 'dream', 'expensive','class', 'smooth', 'pricey', 'elite', 'favorite','appreciate', 'brand', 'have']

# Finding aspirational words from above defined list in the comments
def aspire(Lemma):
    tokens = word_tokenize(Lemma)
    aspire_words=[]
    for item in tokens: 
        if item.lower() in (string.lower() for string in aspiration) and item.lower() not in (string.lower() for string in aspire_words):
            aspire_words.append(item.lower())
    return aspire_words

data['Aspire'] = data['Lemma'].apply(aspire)

# Only keeping rows which detected aspirational words
df = data.loc[data['Aspire'].str.len() >= 1]

# get a list of words for each comment
pos_col = df['pos'].to_list()
lst_comment_words = []
for sentence in pos_col:
    new_sentence = []
    for t in sentence:
        new_sentence.append(t[0])
    lst_comment_words.append(new_sentence)

df['lst_of_words'] = lst_comment_words

# Getting brand names from the comments¶
model_lookup = pd.read_csv('models.csv',header=None)
brands_np = model_lookup.iloc[:,0].unique()
model_np = model_lookup.iloc[:,1].unique()

def get_brand(sentence):
    result = []
    # lower case all strings
    sentence_lower = [x.lower() for x in sentence]
    # drop duplicates
    sentence_lower = list(dict.fromkeys(sentence_lower))
    # go through the list of car brands
    for brand in brands_np:
        if brand.lower() in sentence_lower:
            if brand.lower() not in result:
                result.append(brand.lower())
    # go through the model list, retraive brand info
    for i,model in enumerate(model_lookup.iloc[:,1]):
        candidate_brands = []
        for j,word in enumerate(sentence_lower):
            if model.lower() == word:
                candidate_brands.append(model_lookup.iloc[i,0])
        if len(candidate_brands) == 1 and candidate_brands[0].lower() not in result:
            result.append(candidate_brands[0].lower())
        elif len(candidate_brands) > 1:
            flg = 0
            for brand_c in candidate_brands:
                if brand_c in result:
                    flg += 1
            if flg == 0:
                result.append(candidate_brands[0].lower())
                    
    return result

brands_in_comments = list(map(lambda x: get_brand(x), lst_comment_words))

df['names'] = brands_in_comments

# Dropping other columns
df1 = df.drop(['page', 'comment_id', 'comment', 'user_id', 'date'], axis=1)

# Filtering data based on positivity and subjectivity for future sentiment analysis
# Positivity: Keeping data with positive values above 0 so that the brands are mentioned in positive context wrt aspirational words.
# Subjectivity: Keeping data with subjective score>=0.5 so that we can assume its the subjective opinion of user regarding the brand which would suggest the user's preference towards the brand.
df2 = df1.loc[(df1['Blob'].str[0] >= 0) & (df1['Blob'].str[1] >= 0.5)]
df2.drop(['pos', 'Blob'], axis=1, inplace=True)
df2.head()

## Calculations and frequencies
# Calculating frequency of different aspirational words from the dataset
data_asp = df1['Aspire'].to_list()
asp_count = [0]*len(aspiration)
for i,w in enumerate(aspiration):
    for sentence in data_asp:
        if w.lower() in sentence:
            asp_count[i] += 1

asp_count_pd = pd.DataFrame({'aspiration':aspiration,'count':asp_count})

# Calculating frequency of combination of brands and aspirational words from the dataset
combinations = []
for w1 in brand_list:
    for w2 in aspiration:
        temp = (w1,w2)
        combinations.append(temp)

combination_freq = [0]*len(combinations)

lst_asp = df1.Aspire.to_list()
lst_brands = df1.names.to_list()
for i,c in enumerate(combinations):
    for j, asp in enumerate(lst_asp):
        if c[0].lower() in lst_brands[j] and c[1].lower() in asp:
            combination_freq[i] += 1

combo_count = pd.DataFrame({'combo':combinations,'count':combination_freq})#.to_csv('combo_count.csv')

# Preparing data for lift calculation
ctr_brands = pd.read_csv('brand_count.csv')
print(ctr_brands)
ctr_brands_car = ctr_brands.loc[~ctr_brands.brand.isin(['car','problem','sedan','seat'])]

N = len(data)

# Calculating lift values for each (brand, aspirational word) pair
recorded_combo = []
lift=[]
ctr_brands['brand']

for w1,w2 in combinations:
    #print(w1,w2)
    if w1 in ctr_brands_car['brand'].to_list() and w2 in asp_count_pd['aspiration'].to_list():
        #print('here')
        pw1 = ctr_brands_car.loc[ctr_brands_car.brand==w1]['count'].values[0]
        pw2 = asp_count_pd.loc[asp_count_pd.aspiration==w2]['count'].values[0]
        combo_info = combo_count.loc[combo_count.combo == (w1, w2)]['count'].values[0]
        if pw1>0 and pw2>0:
            recorded_combo.append((w1,w2))
            lift.append(N*(combo_info/(pw1*pw2)))

combo_lift = pd.DataFrame({'recorded_combo':recorded_combo,'lift':lift})
combo_lift.to_csv('part_e_lift.csv')

## Sentiment Analysis
# Recall that we performed sentiment analysis on comments. Count the most mentioned brands under comments that identified as positive sentiment.
pos_brands = list(itertools.chain.from_iterable(df2.names.to_list()))
pos_brands_count = [x for x in pos_brands if x not in ['car','problem','sedan','seat']]
pos_brand_pd = pd.DataFrame(list(Counter(pos_brands_count).items()),columns=['brand','count']).sort_values(by='count',ascending=False)

# Percentage of positive sentiment comment to total brand mention count
merged_pd = pos_brand_pd.merge(ctr_brands_car, on='brand')
merged_pd.columns = ['brand','pos_count','total_count']
merged_pd['pos_pct'] = merged_pd['pos_count']/merged_pd['total_count']
merged_pd.sort_values(by='pos_pct',ascending=False)
merged_pd.to_csv('pos_comment_pct.csv')