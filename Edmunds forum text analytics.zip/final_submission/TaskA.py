import json
import numpy as np
import pandas as pd
import collections
import nltk
import itertools

# Load previous cleaned JSON file.
with open('comments_cleaned.json', 'r') as fp:
    loaded_data = json.load(fp)
# Load car brand and model look up.
model_lookup = pd.read_csv('models.csv',header=None)
brands_np = model_lookup.iloc[:,0].unique()
model_np = model_lookup.iloc[:,1].unique()

# Select the first 5000 comments. Transform tagged sentences, keep only singular nouns.
tagged_sentences = loaded_data['tagged_filtered_sentence'][:5000]
tagged_sentences_lower = []
noun_tags = ['FW','NN','NNS','NNP','NNPS','SYM']
stemmer = nltk.PorterStemmer()
for sentence in tagged_sentences:
    new_sentence = []
    for word_t in sentence:
        if word_t[1] in noun_tags:
            if word_t[1] == 'NNS':
                word_t[0] = stemmer.stem(word_t[0])
                word_t[1] = 'NN'
            elif word_t[1] == 'NNPS':
                word_t[0] = stemmer.stem(word_t[0])
                word_t[1] = 'NNP'
            new_sentence.append(word_t[0])
    tagged_sentences_lower.append(new_sentence)

# Count the appearence of each brand for each of the comment.
def get_brand(sentence):
    result = []
    # lower case all strings
    sentence_lower = [x.lower() for x in sentence]
    # drop duplicates
    sentence_lower = list(dict.fromkeys(sentence_lower))
    # go through the list of car brands
    for brand in brands_np:
        if brand.lower() in sentence_lower:
            if brand.lower() not in result:
                result.append(brand.lower())
    # go through the model list, retraive brand info
    for i,model in enumerate(model_lookup.iloc[:,1]):
        candidate_brands = []
        for j,word in enumerate(sentence_lower):
            if model.lower() == word:
                candidate_brands.append(model_lookup.iloc[i,0])
        if len(candidate_brands) == 1 and candidate_brands[0].lower() not in result:
            result.append(candidate_brands[0].lower())
        elif len(candidate_brands) > 1:
            flg = 0
            for brand_c in candidate_brands:
                if brand_c in result:
                    flg += 1
            if flg == 0:
                result.append(candidate_brands[0].lower())
                    
    return result
                    
brands_in_comments = list(map(lambda x: get_brand(x), tagged_sentences_lower))
lst_of_brands_comments = list({x for l in brands_in_comments for x in l})

# Brands info is extracted from each comment, with one brand only counted once. Now under each brand we count its appearance.
brand_count = [0]*len(lst_of_brands_comments)
for i,brand in enumerate(lst_of_brands_comments):
    for comment_info in brands_in_comments:
        if brand in comment_info:
            brand_count[i] += 1
            
sorted_brand_count = pd.DataFrame({'brand':lst_of_brands_comments,'count':brand_count}).sort_values(by='count',ascending=False).reset_index(drop=True)
sorted_brand_count.to_csv('brand_count.csv',index=False)

# Brand Association and lift
remove_terms = ['car','problem','sedan','seat']
lst_of_brands = [x for x in lst_of_brands_comments if x not in remove_terms]
combos = list(itertools.combinations(lst_of_brands, 2))

# Count combo appearence in each comment
combos_count = [0] * len(combos)
brand_1 = []
brand_2 = []
for i,c in enumerate(combos):
    brand_1.append(c[0])
    brand_2.append(c[1])
    for brands in brands_in_comments:
        if c[0] in brands and c[1] in brands:
            combos_count[i] += 1

mention_combo = pd.DataFrame({'brand1':brand_1,'brand2':brand_2,'count':combos_count})

full_count_1 = mention_combo.merge(sorted_brand_count, left_on='brand1', right_on='brand',suffixes=('_joint', '_brand1')).drop(columns=['brand'])

N = 5000
full_count = full_count_1.merge(sorted_brand_count, left_on='brand2', right_on='brand').drop(columns=['brand'])
full_count.columns = list(full_count.columns)[:-1] + ['count_brand2']
full_count['lift'] = (full_count.count_joint/(full_count.count_brand1*full_count.count_brand2)) * N
full_count

full_count.to_csv('count_and_lift.csv',index=False)

# Construct a dissimilarity matrix with lift.
full_count.sort_values(by='lift', ascending=False).head(10)

def construct_dissimilarity_matrix(df,brand_lst):
    lift_matrix = {}
    for brand_a in brand_lst:
        #print('A:',brand_a)
        lift_matrix[brand_a] = []
        sub_lift_df1 = df[df.brand1 == brand_a]
        for brand_b in brand_lst:
            #print('B:',brand_b)
            sub_lift_df2 = sub_lift_df1[sub_lift_df1.brand2 == brand_b]
            if len(sub_lift_df2) == 0:
                #try opposite order combo
                sub_lift_df3 = df[df.brand2 == brand_a]
                sub_lift_df4 = sub_lift_df3[sub_lift_df3.brand1 == brand_b]
                if len(sub_lift_df4) > 0:
                    value_0 = sub_lift_df4['lift'].values[0]
                    if value_0 != 0:
                        lift_matrix[brand_a].append(1/value_0)
                    else:
                        lift_matrix[brand_a].append(value_0)
                else:
                    lift_matrix[brand_a].append(0)
            else:
                value_1 = sub_lift_df2['lift'].values[0]
                if value_1 != 0:
                    lift_matrix[brand_a].append(1/value_1)
                else:
                    lift_matrix[brand_a].append(value_1)
    return lift_matrix

dissimilarity_df = pd.DataFrame(construct_dissimilarity_matrix(full_count,lst_of_brands))
dissimilarity_df

# MDS plot
mds = MDS(n_components=2,random_state=0, dissimilarity='precomputed')
data_transformed = mds.fit_transform(dissimilarity_df)
data_transformed

figure(figsize=(12, 10), dpi=200)
plt.scatter(data_transformed[:,0],data_transformed[:,1])
plt.title('Brand Association MDS Plot')
for i, txt in enumerate(lst_of_brands):
    plt.annotate(txt, (data_transformed[i,0], data_transformed[i,1]))
plt.show()

# Top 10 brands association
top_10 = sorted_brand_count[~sorted_brand_count.brand.isin(remove_terms)].head(10).reset_index(drop=True)
top_10

top10_brand_lst = top_10.brand.to_list()

dissimilarity_top10 = pd.DataFrame(construct_dissimilarity_matrix(full_count,top10_brand_lst))
mds_top10 = MDS(n_components=2,random_state=0, dissimilarity='precomputed')
data_transformed_top10 = mds_top10.fit_transform(dissimilarity_top10)
figure(figsize=(12, 10), dpi=200)
plt.scatter(data_transformed_top10[:,0],data_transformed_top10[:,1])
plt.title('Top 10 Brand Association MDS Plot')
for i, txt in enumerate(top10_brand_lst):
    plt.annotate(txt, (data_transformed_top10[i,0], data_transformed_top10[i,1]))
plt.show()