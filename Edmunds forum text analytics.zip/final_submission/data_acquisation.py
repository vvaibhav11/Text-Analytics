### Edmunds Data Acquisation ###
import requests
from bs4 import BeautifulSoup
import pandas as pd
from nltk.tokenize import word_tokenize
import nltk
import string 
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
import json

# Fetch at least 5,000 posts from Edmunds
midsize_sedan_url = "https://forums.edmunds.com/discussion/7526/general/x/midsize-sedans-2-0"

# Helper function that extract desired information from 1 comment.
def extract_comment_info(item):
    comment_id = item.find(class_='Permalink').get("href").split('/')[-1].split('_')[-1]
    user_id = item.find(class_='Author').find("a").get("data-userid")
    date = item.find(class_='Permalink').find("time").get("title")
    comment = item.find(class_='Message userContent').text
    #remove newline character 
    comment_mod = comment.replace("\n","")
    return [comment_id,user_id,date,comment_mod]
        
page_url_str = '/p'
# Helper function that extract desired information from page.
def extract_n_pages_comments(url, n_pages, tokenize_flg = False):
    page_url_str = '/p'
    if tokenize_flg:
        comments_dict = {'page':[],'comment_id':[],'user_id':[],'date':[],'comment':[],'comment_tokenized':[]}
    else:
        comments_dict = {'page':[],'comment_id':[],'user_id':[],'date':[],'comment':[]}
    for n in range(n_pages):
        pg_n = n+1
        if pg_n == 1:
            page_str = ''
        else:
            page_str = page_url_str + str(pg_n)
        print("Currently working on page:", pg_n)
        page = requests.get(url+page_str)
        page_text = page.text
        page_soup = BeautifulSoup(page_text, 'html.parser')
        page_comments = page_soup.find_all(class_='Comment')
        page_comment_id_lst = []
        page_user_id_lst = []
        page_date_lst = []
        page_comment_lst = []
        if tokenize_flg:
            page_comment_t_lst = []
        for comment in page_comments:
            page_comment_info = extract_comment_info(comment)
            page_comment_id_lst.append(page_comment_info[0])
            page_user_id_lst.append(page_comment_info[1])
            page_date_lst.append(page_comment_info[2])
            page_comment_lst.append(page_comment_info[3])
            if tokenize_flg:
                page_comment_t_lst.append(word_tokenize(page_comment_info[3]))
        page_lst = [str(pg_n)]*len(page_comment_id_lst)
        comments_dict['page'] += page_lst
        comments_dict['comment_id'] += page_comment_id_lst
        comments_dict['user_id'] += page_user_id_lst
        comments_dict['date'] += page_date_lst
        comments_dict['comment'] += page_comment_lst
        if tokenize_flg:
            comments_dict['comment_tokenized'] += page_comment_t_lst
    return comments_dict

comments = extract_n_pages_comments(midsize_sedan_url, 150,tokenize_flg = True)

# Save raw comments data
pd.DataFrame(dict((key,value) for key, value in comments.items() if key != 'comment_tokenized')).to_csv('comments_raw.csv',index=False)

# Remove stop words
stemmer = PorterStemmer()
stop_words = stopwords.words('english')
lst_of_tokenized = comments['comment_tokenized']
for sentence in lst_of_tokenized:
    new_sentence = []
    for s in sentence:
        if s in string.punctuation or s == '..':
            sentence.remove(s)
        if s in stop_words:
            sentence.remove(s)
            
# Tagging Tokens
remove_lst = ['CC','CD','DT','EX','IN','LS','PDT','PRP','POS','RP','VBP','VBZ','TO','UH','WDT','WP','WP$','WRB']
def remove_unwanted_words(tagged_sentence):
    new_sentence = []
    for word_tuple in tagged_sentence:
        if word_tuple[1] not in remove_lst:
            new_sentence.append(word_tuple)
    return new_sentence

# For each comment, remove unwanted words
lst_tagged_sentences = []
for sentence in lst_of_tokenized:
    tagged_lst = nltk.pos_tag(sentence)
    tagged_lst_filtered = remove_unwanted_words(tagged_lst)
    lst_tagged_sentences.append(tagged_lst_filtered)
    
comments['tagged_filtered_sentence'] = lst_tagged_sentences

# Check point: JSON file
with open('comments_cleaned.json', 'w') as fp:
    json.dump(comments, fp)

# Load JSON file
with open('comments_cleaned.json', 'r') as fp:
    loaded_data = json.load(fp)